/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// define is used to register a module in require js 
//define([
//          "jquery"
//     ], function($) {
// 
//     console.log('called');
//        //defining our plugin
//    $.fn.mycomponent = function(options) {
//         
//        // get initialised data here
//        console.log(options);
//         
// 
//        // 'your plugin is ready do whatevent you want to do'
//                     
//    };
// 
// 
//});

