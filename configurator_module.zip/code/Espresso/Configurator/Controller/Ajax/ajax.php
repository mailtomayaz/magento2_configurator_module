<?php
 
namespace Espresso\Configurator\Controller\Ajax;
 use Magento\Framework\App\Action\Context;
 
class Ajax extends \Magento\Framework\App\Action\Action
{
   protected $_resultPageFactory;
   protected $resultJsonFactory;
 
    public function __construct(Context $context, 
            \Magento\Framework\View\Result\PageFactory $resultPageFactory ,
            \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
    {
        $this->_resultPageFactory = $resultPageFactory;
         $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }
 
    public function execute()
    {

//        return $resultPage;
        $productData=array();
        $productDataDynamic=array();
            $model = $this->getRequest()->getParam('model');
            $color = $this->getRequest()->getParam('color');
            $type = $this->getRequest()->getParam('type');
            $brandpatren = $this->getRequest()->getParam('brandpatren');
           //'model ='+brandModel+' color= '+brandColor + " type ="+brandDesignType+ " brandpatren="+brandPatren
        
//        $height = $this->getRequest()->getParam('height');
//        $weight = $this->getRequest()->getParam('weight');
//        $result = $this->$_resultPageFactory->create();
//        $resultPage = $this->$_resultPageFactory->create();
//         $block = $resultPage->getLayout()
//                ->createBlock('Espresso\Configurator\Block\Index')
//                ->setTemplate('Espresso_Configurator::configurator.phtml')
//                ->setData('height',$height)
//                ->setData('weight',$weight)
//                ->toHtml();
       // $result->setData(['output' => $block]);
             $resultPage = $this->_resultPageFactory->create();
             //        $resultPage = $this->_resultPageFactory->create();
                     $block = $resultPage->getLayout()->getBlock('configurator');
           // $getBlock = $this->getLayout()->createBlock("Espresso\Configurator\Block\Epconfigurator");
            $data = $block->getProductWithScreenAttributesCollection();
            $dataDynamic = $block->getProductWithPunchAttributesCollection($model,$color,$type,$brandpatren);
            //$resultPage->setData(['output' => $data]);
            //    print_r($data->getData());    
            //$resultJson = $this->resultJsonFactory->create();
            foreach ($data as $value) {
                 //echo "<pre>";
                $productData = $value->getData();
                //exit;
        
             }
                foreach ($dataDynamic as $value) {
                 //echo "<pre>";
                $productDataDynamic = $value->getData();
                //exit;
        
             }
              $resultJson = $this->resultJsonFactory->create();
               //return $resultJson->setData(['productInfo' => $productData]);
         
               return $resultJson->setData(['productInfo' => $productDataDynamic]);
// print_r($data->getData());
         //  return $resultPage;

    }
}